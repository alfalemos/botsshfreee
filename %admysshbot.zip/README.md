__Você precisa criar um bot no [@botfather](https://t.me/botfather) para fazer a instalação__

Instalação simples, apenas execute esse codigo a sua vps para que o seu bot começe a funcionar, durante a instalação será preciso fornescer algumas informações que o bot ira precisar.

```wget https://raw.githubusercontent.com/alfalemos/alfalemos/main/iniciar.sh; chmod +x iniciar.sh; ./iniciar.sh```


Com esse script você terá um bot de contas SSH gratís e funçional.

__Pacotes nescessarios:__
- php
- php-curl
- php-redis
- redis-server
- screen
- zip

nosso telegram 
https://t.me/alfalemos

